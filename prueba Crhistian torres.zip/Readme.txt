este proyecto esta creado con angular(frontend) y laravel(backend), la base de datos mysql.
con token(JWT),material angular, primeNg.

 
*nombre de la base de datos "prueba".
*ApisLaravel(backend), son las apis Nota: importante verificar el archivo .env donde esta la conexion de la base de datos.
*en ApisLaravel en la raiz encontraras una carpeta llamada form, en esa carpeta se encuentra el front en produccion.
*la url para entra al proyecto seria http://localhost/Apilaravel/form
*pruebaFront(frontend) es el codigo fuente del frontend,esta creado con angular
*si quieren pasar el codigo en angular en produccion ejecutar el codigo => 
	ng build --aot --output-hashing=all --base-href /ApisLaravel/form/

/*****INSTALACION*****/

1.ejecute xampp o cualquier servidor web local.
2.crear base de datos llamada prueba, importe el archivo .mysql para crear las tablas.
3.copie la carpeta ApiLaravel y pegala en htdocs
4.en el explorador direjese ala direccion http://localhost/ApisLaravel/form
5. usuario: master, password:Abc123

