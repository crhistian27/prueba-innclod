export interface interTipo {
    TIP_ID : number,
    TIP_NOMBRE:string,
    TIP_PREFIJO:string,
}