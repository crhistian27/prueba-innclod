export interface estrucUser  {
    usuario:string,
    password:string
}