export interface interProceso {
    PRO_ID : number,
    PRO_PREFIJO:string,
    PRO_NOMBRE:string,
}