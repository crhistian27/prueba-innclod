export interface interDocumento {
    DOC_ID : number,
    DOC_NOMBRE:string,
    DOC_CODIGO:string,
    DOC_CONTENIDO:string,
    DOC_ID_TIPO:number,
    DOC_ID_PROCESO:number,
    TIPO:string,
    PROCESO:string,
    PREFIJO1:string,
    PREFIJO2: string
}
