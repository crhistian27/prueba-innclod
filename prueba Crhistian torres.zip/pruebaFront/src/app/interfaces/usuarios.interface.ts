export interface interUsuarios {
    user_id : number,
    user_user:string,
    user_password:string
}