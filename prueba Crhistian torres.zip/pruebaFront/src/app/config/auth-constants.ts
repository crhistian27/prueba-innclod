export class AuthConstants{ 
    public static readonly AUTH = 'portalPrueba'
  }
  