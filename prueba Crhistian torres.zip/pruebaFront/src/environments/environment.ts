export const environment = {
    production: false,
    apiUrl: 'http://localhost/ApisLaravel/public/api/'

};
